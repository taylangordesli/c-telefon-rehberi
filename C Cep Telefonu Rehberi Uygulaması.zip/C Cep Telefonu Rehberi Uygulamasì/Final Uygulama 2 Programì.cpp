//Kay�t ekleme, kay�t listesi g�sterme, kay�t arama ve kay�t silme gibi i�levleri olan telefon rehberi.
#include <locale.h> //--> T�rk�e karakterleri g�r�nt�leyebilmek i�in k�t�phane tan�mlad�m.
#include <stdio.h> //--> Standart giri� ��k�� birimleri i�in k�t�phane tan�mlad�m.
#include <stdlib.h> //--> �e�itli genel ama�l� fonksiyonlar i�in k�t�phane tan�mlad�m.
#include <string.h> //--> Karakter dizileri ile ilgili fonksiyon, veri t�r� ve makro tan�mlamalar� i�in k�t�phane tan�mlad�m.
#include <conio.h>
#include <windows.h> 
struct kisiBilgi
{
	char ad[50];
	char soyad[50];
	char sehir[50];
	double telNo;	
}kisi;
void menu()
{
	printf("\n");
	printf("\t\t\t\t\t ------------------------- \n");
	printf("\t\t\t\t\t|          MENU           |\n");
	printf("\t\t\t\t\t ------------------------- \n");
	printf("\t\t\t\t\t| 1. Ki�i Ekle            |\n");
	printf("\t\t\t\t\t| 2. Rehberi G�r�nt�le    |\n");   
	printf("\t\t\t\t\t| 3. Ki�i Ara             |\n");
	printf("\t\t\t\t\t| 4. Ki�i Sil             |\n");
	printf("\t\t\t\t\t| 5. ��k��                |\n");
	printf("\t\t\t\t\t|-------------------------|\n");
	printf("\t\t\t\t\t -      Se�iminiz ?      - \n");
	printf("\t\t\t\t\t ------------------------- \n");
}
void listeMenu()
{
	// Liste Men�
	printf("|------------------------------------------------------------------------------------------------------------|\n");
	printf("|AD			|SOYAD 			     |�EH�R                      |NUMARA                     |\n");
	printf("|------------------------------------------------------------------------------------------------------------|\n");
}
void kayitEkle()
{
	printf("Kaydetmek istedi�iniz ki�inin ad�: ");
	scanf("%s",kisi.ad);
	printf("\nKaydetmek istedi�iniz ki�inin soyad�: ");
	scanf("%s",kisi.soyad);
	printf("\nKaydetmek istedi�iniz ki�inin ya�ad��� �ehir: ");
	scanf("%s",kisi.sehir);
	printf("\nKaydetmek istedi�iniz ki�inin telefon numaras� (10 hane olarak giriniz.): +90");
	scanf("%lf",&kisi.telNo);
	FILE *pdosya = fopen("kayitlistesi.txt","a");
	fprintf(pdosya,"|%s		         %s	 		  %s			   +90%.0lf                       \n",kisi.ad,kisi.soyad,kisi.sehir,kisi.telNo);	
	fprintf(pdosya,"|------------------------------------------------------------------------------------------------------------|\n");
	fclose(pdosya);	
	//Arama i�leminin kullanabilece�i bir liste olu�turuyorum.
	/*FILE *fp = fopen("aramaListesi.txt","a");
	fprintf(fp,"Ad: %s\n",kisi.ad);
	fprintf(fp,"Soyad: %s\n",kisi.soyad);
	fprintf(fp,"�ehir: %s\n",kisi.sehir);
	fprintf(fp,"Telefon Numaras�:+90%.0lf\n",kisi.telNo);
	fprintf(fp,"\n");
	fclose(fp);*/
	FILE *fp = fopen("aramaListesi.txt","a");
	fprintf(fp,"|%s		         %s	 		  %s			   +90%.0lf                       \n",kisi.ad,kisi.soyad,kisi.sehir,kisi.telNo);	
	fprintf(fp,"|------------------------------------------------------------------------------------------------------------|\n");
	fclose(fp);	
}
int kayitListe()
{
	setlocale(LC_ALL,"Turkish");
	FILE *pdosya = fopen("kayitlistesi.txt","r");
	if(pdosya == NULL)
	{
		printf("Herhangi bir kay�t bulunamad�.");
	}
	else
	{
		listeMenu();
		while(!feof(pdosya))
		{
			putchar(fgetc(pdosya));
		}
	}	
	fclose(pdosya);
}
int kayitSil()
{
	FILE *pdosya = fopen("kayitlistesi.txt","w");
	fprintf(pdosya,"");
	fclose(pdosya);
	FILE *fp = fopen("aramaListesi.txt","w");
	fprintf(fp,"");
	fclose(fp);
}
int kayitArama()
{
	FILE *fp = fopen("aramaListesi.txt","r");
	char arananIsim[40];
	printf("Bulmak istedi�iniz ki�inin ismini giriniz: ");
	scanf("%s",&arananIsim);
	printf("\n");
	rewind(fp);	
	while(!feof(fp))
	{
		if(strcmp(kisi.ad,arananIsim)==0)
		{
			listeMenu();
			printf("|%s		         %s	 		  %s			   +90%.0lf                       \n",kisi.ad,kisi.soyad,kisi.sehir,kisi.telNo);
			printf("|------------------------------------------------------------------------------------------------------------|\n");
			break;	
		}
		else
		{
			printf("'%s' isimli bir kay�t bulunamad�.",arananIsim);
			break;
		}
	}
	fclose(fp);
}
int main()
{
	setlocale(LC_ALL,"Turkish");
	secim_noktasi:
	menu();
	int secim;
	printf("\n\t\t\t\t\t\t    ");
	scanf("%d",&secim);
	switch(secim)
	{
		case 1: // Kay�t Ekleme
		{
			printf("\n");
			kayitEkle();
			printf("\n");
			printf("Ana ekrana d�nd�r�l�yorsunuz...\n");
			goto secim_noktasi;
		}
		case 2: // Kay�t Listesi
		{
			printf("\n");
			kayitListe();
			printf("\n");
			printf("Ana ekrana d�nd�r�l�yorsunuz...\n");
			goto secim_noktasi;
		}
		case 3: // Kay�t Arama
		{
			printf("\n");
			kayitArama();
			printf("\n");
			printf("Ana ekrana d�nd�r�l�yorsunuz...\n");
			goto secim_noktasi;
		}
		case 4: // Kay�t Silme
		{
			char secim1;
			printf("\nT�m kay�tlar�n�z silinecek onayl�yor musunuz ?\nE/H: ");
			scanf(" %c",&secim1);
			if(secim1=='E' || secim1=='e')
			{
				kayitSil();
				printf("Kay�t ba�ar�yla silindi !\n");
				printf("Ana ekrana d�nd�r�l�yorsunuz...\n");
				goto secim_noktasi;
			}
			if(secim1=='H' || secim1=='h')
			{
				printf("Ana ekrana d�nd�r�l�yorsunuz...\n");
				goto secim_noktasi;
			}
		}
		case 5: // ��k��
		{
			break;
		}
	}
}
